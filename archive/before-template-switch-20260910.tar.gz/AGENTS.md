# CUMCM 2026 project instructions

- This repository is the paper writer's workspace. Preserve `cumcmthesis.cls` and `cumcm2026.sty` unless the user explicitly asks to change the template layer.
- Keep `main.tex` as a thin assembly entry; write paper content in `contents/`.
- Put reproducible plotting scripts in `scripts/plotting/` and final figures in `figures/final/`.
- Never invent numerical results, citations, experiments, or model performance. Every quantitative claim must trace to `results/`, `data/`, or executable code.
- Keep competition inputs in `data/` unchanged. Derived files belong in `results/`.
- Compile with `latexmk main.tex` and inspect `build/main.pdf` before declaring paper changes complete.
- Maintain the AI-use declaration according to actual usage, and check all outputs for identity information before submission.
