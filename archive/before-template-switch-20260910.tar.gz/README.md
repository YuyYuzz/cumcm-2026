
# CUMCM 2026 论文工作区

本仓库是全国大学生数学建模竞赛论文写作与绘图工作区，使用 XeLaTeX 编译。
底层文档类来自 [latexstudio/CUMCMThesis](https://github.com/latexstudio/CUMCMThesis)，
分文件架构参考 [jayxin/cumcm](https://github.com/jayxin/cumcm)。

## 快速编译

```bash
latexmk main.tex
```

生成文件位于 `build/main.pdf`。提交前至少检查摘要页、页码、匿名信息、图表清晰度、
参考文献引用和 AI 工具使用声明。

## 目录说明

```text
.
├── main.tex                 # 唯一论文入口
├── config/                  # 宏包、图片路径和自定义命令
├── contents/
│   ├── abstract.tex         # 摘要和关键词
│   ├── info.tex             # 论文标题
│   ├── ai_usage.tex         # AI 工具使用声明
│   ├── references.tex       # 参考文献入口
│   ├── sections/            # 正文分章节文件
│   └── appendix/            # 附录和支撑材料清单
├── references/              # BibTeX 文献库
├── figures/
│   ├── source/              # 可编辑图源和绘图中间材料
│   └── final/               # 论文实际引用的最终图片
├── scripts/plotting/        # 可复现绘图脚本
├── data/                    # 原始数据，只读保存
├── results/                 # 模型输出和绘图输入
├── tables/                  # 可复用表格数据或 TeX 片段
├── code/                    # 建模求解代码
├── docs/                    # 规范、记录和外部模板说明
├── cumcmthesis.cls          # 国赛文档类
├── cumcm2026.sty            # 2026 排版与 AI 声明扩展
└── build/                   # 编译产物，不提交 Git
```

## 写作约定

- 正文只写入 `contents/`，不要把长篇内容继续堆入 `main.tex`。
- 最终图只放 `figures/final/`，对应脚本放 `scripts/plotting/`。
- 原始数据保持不改；清洗或计算后的数据写入 `results/`。
- 图题置于图下，表题置于表上；图片优先使用 PDF/SVG，栅格图至少 300 DPI。
- 每个关键数字应能追溯到 `results/` 或建模代码输出。
- AI 声明必须按比赛期间的真实使用情况维护。

## 项目内 Skills

- `mathmodel-figure`：论文级科研绘图和多格式导出。
- `mathmodel-paper`：摘要、LaTeX/PDF/Word 排版工具链和不可见字符检查。

它们位于 `.agents/skills/`，只对本项目生效。
